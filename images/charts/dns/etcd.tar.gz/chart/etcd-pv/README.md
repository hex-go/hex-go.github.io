## 部署

指定pv所在节点
```bash
kubectl label node 节点名称 benchmark=fio
```

在指定的1个节点下创建目录
```bash
mkdir /mnt/ps-fio-m1c2-benchmark-data/
```

修改配置,并手动建卷
```yaml
# values.yaml做如下修改
pvc:
  enabled: "true"
  accessModes: ReadWriteOnce
  storageClassName: fio-storage
  size: 20Gi
  path: /mnt
```

手动创建卷
```bash
kubectl create -f fio-pv/pv.yaml -n benchmark
```

## 参照INSTALL.md 接着部署服务
